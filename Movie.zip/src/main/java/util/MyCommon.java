package util;

public class MyCommon {
	
	public static class Visit{
		
		public static final String VIEW_PATH = "/WEB-INF/views/";
	}
}
