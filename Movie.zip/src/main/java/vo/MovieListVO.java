package vo;

public class MovieListVO {
	private int idx;
	private String moviename,movietheater,moviedate,movietimelist;
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getMoviename() {
		return moviename;
	}
	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
	public String getMovietheater() {
		return movietheater;
	}
	public void setMovietheater(String movietheater) {
		this.movietheater = movietheater;
	}
	public String getMoviedate() {
		return moviedate;
	}
	public void setMoviedate(String moviedate) {
		this.moviedate = moviedate;
	}
	public String getMovietimelist() {
		return movietimelist;
	}
	public void setMovietimelist(String movietimelist) {
		this.movietimelist = movietimelist;
	}
}
